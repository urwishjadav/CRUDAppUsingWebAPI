﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiCRUD.Models;

namespace WebApiCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAPIController : ControllerBase
    {
        private readonly db_DEMOContext context;

        public StudentAPIController(db_DEMOContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<TblStudent>>> GetStudents()
        {
            var data = await context.TblStudents.ToListAsync();
            return Ok(data);
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<TblStudent>> GetStudentById(int id)
        {
            var student = await context.TblStudents.FindAsync(id);
            if (student == null)
            {
                return NotFound();
            }
            return student;
        }


        [HttpPost]
        public async Task<ActionResult<TblStudent>> CreateStudent(TblStudent std)
        {
            await context.TblStudents.AddAsync(std);
            await context.SaveChangesAsync();
            return Ok(std);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<TblStudent>> UpdateStudent(int id,TblStudent std)
        {
            if (id!= std.Id)
            {
                return BadRequest();
            }
            context.Entry(std).State = EntityState.Modified;
            await context.SaveChangesAsync();
            return Ok(std);
        }



        [HttpDelete("{id}")]
        public async Task<ActionResult<TblStudent>> DeleteStudent(int id)
        {
            var std = await context.TblStudents.FindAsync(id);
            if (std== null)
            {
                return NotFound();
            }
            context.TblStudents.Remove(std);
            await context.SaveChangesAsync();
            return Ok(std);
        }
    }
}

